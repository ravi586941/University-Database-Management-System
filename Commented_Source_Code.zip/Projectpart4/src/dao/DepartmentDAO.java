package dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.NamingException;




import bean.InstructorsBean;
import bean.CoursesBean;
import bean.DepartmentBean;

public class DepartmentDAO {

	Connection conn = null;
		public static DepartmentBean departmentslist(DepartmentBean db)
			throws ClassNotFoundException, NamingException {

		try {
			
			System.out.println("Entered try block in DAO");
			Connection myConn = DBConnection.createDatabaseConnection();
			Statement mystmt = myConn.createStatement();
			ResultSet rs = mystmt.executeQuery("select * from department order by DepartmentName asc");
			System.out.println("Entering while loop :IN DAO");
			//db.store=rs.getString("DepartmentName");
			ArrayList a = new ArrayList();
			while (rs.next()) {
				a.add(rs.getString("DepartmentName"));
				db.DepartmentName=rs.getString("DepartmentName");
				//System.out.println(rs.getString("DepartmentName"));
				db.setFlag(1);
				db.store=a;
				System.out.println(db.store);
					}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return db;

	}

	public static InstructorsBean csfaculty(InstructorsBean csf) throws ClassNotFoundException, NamingException {
		// TODO Auto-generated method stub
		try {
			
			System.out.println("Entered try block in csf DAO");
			Connection myConn = DBConnection.createDatabaseConnection();
			Statement mystmt = myConn.createStatement();
			ResultSet rs = mystmt.executeQuery("select * from instructors where DepartmentName='COMPUTER SCIENCE'");
			System.out.println("Entering while loop csf:IN DAO");
			ArrayList a = new ArrayList();
			while (rs.next()) {
				a.add(rs.getString("FirstName")+" "+rs.getString("EmailID")+" "+rs.getString("Qualification")+" "+rs.getString("Designation")+" "+rs.getString("PhoneNumber"));
				System.out.println(rs.getString("DepartmentName"));
				csf.setFlag(1);
				csf.store=a;
				System.out.println(csf.store);
					}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return csf;
	}

	public static CoursesBean courselist(CoursesBean cb) throws ClassNotFoundException, NamingException {
		// TODO Auto-generated method stub
try {
			
			System.out.println("Entered try block in csf DAO");
			Connection myConn = DBConnection.createDatabaseConnection();
			Statement mystmt = myConn.createStatement();
			ResultSet rs = mystmt.executeQuery("select * from courses where DepartmentName='COMPUTER SCIENCE'");
			System.out.println("Entering while loop cb:IN DAO");
			ArrayList a = new ArrayList();
			while (rs.next()) {
				a.add(rs.getString("CourseID")+" "+rs.getString("CourseName")+" "+rs.getString("Credits")+" "+rs.getString("InstructorID"));
				System.out.println(rs.getString("CourseID"));
				cb.setFlag(1);
				cb.store=a;
				//System.out.println(cb.store);
					}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cb;
		
			}

	public static CoursesBean addcourse(CoursesBean cb) throws ClassNotFoundException, NamingException {
		// TODO Auto-generated method stub
		
try {
			
			System.out.println("Entered try block in add course DAO");
			Connection myConn = DBConnection.createDatabaseConnection();
			System.out.println("Course Id is"+cb.getCourseID());
			//String query="insert into courses values('?','?','?','?','?','?','?','?')";
			System.out.println("queary started");
			PreparedStatement ps1=myConn.prepareStatement("insert into instructors (InstructorID) values (?)");
			PreparedStatement ps2= myConn.prepareStatement("insert into courses values(?,?,?,?,?,?,?,?)");
			
			ps2.setInt(1, cb.getCourseID());
			ps2.setString(2, cb.getCourseName());
			ps2.setString(3, cb.getInstructorID());
			ps2.setString(4, cb.getDepartmentName());
			ps2.setInt(5, cb.getCredits());
			ps2.setString(6, cb.getOfferedYearSemester());
			ps2.setInt(7, cb.getBuildingNumber());
			ps2.setString(8, cb.getBuildingCode());
			ps1.setString(1, cb.getInstructorID());
			ps1.execute();
			ps2.execute();
			System.out.println("insert queary executed");
			Statement mystmt = myConn.createStatement();
			ResultSet rs = mystmt.executeQuery("select * from courses where DepartmentName='COMPUTER SCIENCE'");
			System.out.println("Entering while loop cb:IN DAO");
			ArrayList a = new ArrayList();
			while (rs.next()) {
				a.add(rs.getString("CourseID")+" "+rs.getString("CourseName")+" "+rs.getString("Credits")+" "+rs.getString("InstructorID"));
				System.out.println(rs.getString("CourseID"));
				cb.setFlag(1);
				cb.store=a;
					}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
cb.setFlag(1);
		return cb;
		
	}

}